import React from 'react'
import Layout from "../components/layout"

import { StaticImage } from "gatsby-plugin-image"

import Close from "../images/svg/close.svg"
import Location from "../images/svg/location.svg"
import Tel from "../images/svg/tel.svg"
import Hp from "../images/svg/handphone.svg"
import Circle from "../images/svg/circle.svg"


const Contact = (location) => {


    return (
        <Layout location={location}>
            <main className="contact">
                <div className="top">
                    <h4>Contact us and let us help you succeed at your goals!</h4>
                </div>
                <div className="middle">
                    <div className="center">
                        <div className="left">
                            <h4>Get In Touch</h4>
                            <div><Location className="location" /><p>  720 Charcot Ave., San Jose, CA 95131</p></div>
                            <div><Tel className="tel" /><p>  (+1) 408.947.0563 </p></div>
                            <div><Hp className="hp" /><p>  (+1) 408.448.3711</p></div>
                            <form action="post">
                                <div>
                                    <input type="text" name="name" id="name" placeholder="Name" />
                                    <input type="email" name="email" id="email" placeholder="Email Address" />
                                </div>
                                <textarea name="message" id="message" placeholder="Write your message here"></textarea>
                                <input type="submit" value="Send" className="submit"/>
                            </form>
                        </div>
                        <div className="right">

                            <button className="close-container">
                                <Close className="close" />
                            </button>
                            <div className="blue">
                                <Circle className="circle" />
                            </div>
                            <StaticImage src="../images/png/pic.jpeg" alt="background" className="img" />
                        </div>
                    </div>
                </div>
                <div className="background">
                    <StaticImage src="../images/png/bg2.png" alt="background" className="img" />
                </div>
            </main>
        </Layout>
    )
}

export default Contact
